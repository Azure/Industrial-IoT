The Azure IoT Operations extension for Azure CLI. Intended for power users and/or automation of Azure IoT Operations solutions at scale.
